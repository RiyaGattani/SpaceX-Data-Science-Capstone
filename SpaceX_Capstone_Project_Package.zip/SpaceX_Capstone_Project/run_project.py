from __future__ import annotations
import json, time, warnings
from datetime import datetime, timezone
from pathlib import Path

import requests
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from bs4 import BeautifulSoup
import folium

from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
                             confusion_matrix, classification_report)
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.dummy import DummyClassifier
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Image, Table,
                                TableStyle, PageBreak, KeepTogether)

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "outputs"
FIG = ROOT / "figures"
OUT.mkdir(exist_ok=True)
FIG.mkdir(exist_ok=True)
API = "https://api.spacexdata.com/v4"
WIKI = "https://en.wikipedia.org/wiki/List_of_Falcon_9_and_Falcon_Heavy_launches"
HEADERS = {"User-Agent": "Mozilla/5.0 (compatible; SpaceXCapstoneEducationalProject/1.0)"}

def get_json(url, timeout=30):
    r = requests.get(url, headers=HEADERS, timeout=timeout)
    r.raise_for_status()
    return r.json()

def safe_get_json(url):
    try:
        return get_json(url)
    except Exception as e:
        warnings.warn(f"Could not retrieve {url}: {e}")
        return None

def collect_data():
    print("[1/7] Collecting data from SpaceX API...")
    launches = get_json(f"{API}/launches/past")
    rockets = get_json(f"{API}/rockets")
    pads = get_json(f"{API}/launchpads")
    payloads = get_json(f"{API}/payloads")
    cores = get_json(f"{API}/cores")
    pd.json_normalize(launches).to_csv(OUT / "raw_launches.csv", index=False)
    (OUT / "collection_metadata.json").write_text(json.dumps({
        "collected_utc": datetime.now(timezone.utc).isoformat(),
        "launch_records_returned": len(launches),
        "rocket_records_returned": len(rockets),
        "launchpad_records_returned": len(pads),
        "payload_records_returned": len(payloads),
        "core_records_returned": len(cores),
        "source": API
    }, indent=2), encoding="utf-8")
    rocket_by_id = {x.get("id"): x for x in rockets}
    pad_by_id = {x.get("id"): x for x in pads}
    payload_by_id = {x.get("id"): x for x in payloads}
    core_by_id = {x.get("id"): x for x in cores}
    rows = []
    for launch in launches:
        rocket = rocket_by_id.get(launch.get("rocket"), {})
        if rocket.get("name") != "Falcon 9":
            continue
        payload_ids = launch.get("payloads") or []
        core_ids = [c.get("core") for c in (launch.get("cores") or []) if c.get("core")]
        payload_items = [payload_by_id.get(pid, {}) for pid in payload_ids]
        core_items = [core_by_id.get(cid, {}) for cid in core_ids]
        pad = pad_by_id.get(launch.get("launchpad"), {})
        payload_mass = [p.get("mass_kg") for p in payload_items if isinstance(p.get("mass_kg"), (int, float))]
        payload_orbits = [p.get("orbit") for p in payload_items if p.get("orbit")]
        landing_values = [c.get("landing_success") for c in core_items if c.get("landing_success") is not None]
        # First-stage landing success is supervised only when the API supplies an explicit landing label.
        landing_success = landing_values[0] if landing_values else None
        rows.append({
            "flight_number": launch.get("flight_number"),
            "name": launch.get("name"),
            "date_utc": launch.get("date_utc"),
            "year": pd.to_datetime(launch.get("date_utc"), errors="coerce", utc=True).year,
            "booster_version": rocket.get("name"),
            "launch_site": pad.get("name"),
            "launch_site_full_name": pad.get("full_name"),
            "latitude": pad.get("latitude"),
            "longitude": pad.get("longitude"),
            "payload_mass_kg": float(np.sum(payload_mass)) if payload_mass else np.nan,
            "orbit": payload_orbits[0] if payload_orbits else None,
            "landing_success": landing_success,
            "core_reused": any(c.get("reused") is True for c in core_items),
            "landing_type": next((c.get("landing_type") for c in (launch.get("cores") or []) if c.get("landing_type")), None),
            "launch_success": launch.get("success"),
            "details": launch.get("details")
        })
    df = pd.DataFrame(rows).sort_values("flight_number")
    df.to_csv(OUT / "spacex_falcon9_raw.csv", index=False)
    print(f"  API returned {len(launches)} launches; Falcon 9 rows collected: {len(df)}")
    return df

def scrape_wikipedia():
    print("[2/7] Scraping supplemental launch-list table from Wikipedia...")
    try:
        html = requests.get(WIKI, headers=HEADERS, timeout=30)
        html.raise_for_status()
        soup = BeautifulSoup(html.text, "html.parser")
        tables = pd.read_html(str(soup))
        candidates = [t for t in tables if len(t) > 5 and len(t.columns) >= 3]
        if candidates:
            scraped = max(candidates, key=lambda t: len(t))
            scraped.to_csv(OUT / "wikipedia_launch_table.csv", index=False)
            return {"status": "success", "rows": int(len(scraped)), "columns": [str(c) for c in scraped.columns], "source": WIKI}
        return {"status": "no suitable table found", "source": WIKI}
    except Exception as e:
        return {"status": f"unavailable: {e}", "source": WIKI}

def wrangle(df):
    print("[3/7] Wrangling and preparing dataset...")
    df = df.copy()
    df["date_utc"] = pd.to_datetime(df["date_utc"], errors="coerce", utc=True)
    df["year"] = df["date_utc"].dt.year
    df["landing_success"] = df["landing_success"].map({True: 1, False: 0, 1: 1, 0: 0})
    df["core_reused"] = df["core_reused"].map({True: 1, False: 0})
    df["launch_success"] = df["launch_success"].map({True: 1, False: 0, 1: 1, 0: 0})
    # Retain all rows in the cleaned dataset; only the supervised modelling subset excludes unknown labels.
    df = df.drop_duplicates(subset=["flight_number"], keep="first")
    df.to_csv(OUT / "spacex_falcon9_cleaned.csv", index=False)
    return df

def sql_eda(df):
    print("[4/7] Running SQL EDA using SQLite...")
    import sqlite3
    sql_df = df.copy()
    sql_df["date_utc"] = sql_df["date_utc"].astype(str)
    con = sqlite3.connect(OUT / "spacex_capstone.sqlite")
    sql_df.to_sql("launches", con, if_exists="replace", index=False)
    queries = {
        "launches_by_site": """SELECT launch_site, COUNT(*) AS launches
                               FROM launches GROUP BY launch_site ORDER BY launches DESC""",
        "launches_by_year": """SELECT year, COUNT(*) AS launches
                               FROM launches WHERE year IS NOT NULL GROUP BY year ORDER BY year""",
        "landing_outcome_by_site": """SELECT launch_site,
                              SUM(CASE WHEN landing_success=1 THEN 1 ELSE 0 END) AS successful_landings,
                              SUM(CASE WHEN landing_success=0 THEN 1 ELSE 0 END) AS unsuccessful_landings,
                              SUM(CASE WHEN landing_success IS NOT NULL THEN 1 ELSE 0 END) AS labelled_attempts
                              FROM launches GROUP BY launch_site ORDER BY labelled_attempts DESC""",
        "payload_by_orbit": """SELECT orbit, COUNT(*) AS missions,
                              ROUND(AVG(payload_mass_kg), 2) AS average_payload_kg
                              FROM launches GROUP BY orbit ORDER BY missions DESC"""
    }
    results = {}
    for name, query in queries.items():
        results[name] = pd.read_sql_query(query, con).to_dict(orient="records")
        pd.read_sql_query(query, con).to_csv(OUT / f"sql_{name}.csv", index=False)
    con.close()
    (OUT / "sql_queries.json").write_text(json.dumps(queries, indent=2), encoding="utf-8")
    return results

def make_visuals(df):
    print("[5/7] Creating EDA visualizations and Folium map...")
    sns.set_theme()
    # Launch counts by year
    year_counts = df.dropna(subset=["year"]).groupby("year").size()
    fig, ax = plt.subplots(figsize=(9, 4.8))
    year_counts.plot(kind="bar", ax=ax)
    ax.set_title("Falcon 9 Launches by Year")
    ax.set_xlabel("Year"); ax.set_ylabel("Number of launches")
    fig.tight_layout(); fig.savefig(FIG / "launches_by_year.png", dpi=160); plt.close(fig)
    # Landing outcomes by site (only known labels)
    known = df.dropna(subset=["landing_success"]).copy()
    if len(known):
        pivot = known.groupby("launch_site")["landing_success"].agg(["sum", "count"])
        pivot["unsuccessful"] = pivot["count"] - pivot["sum"]
        plot = pivot[["sum", "unsuccessful"]].rename(columns={"sum": "Successful", "unsuccessful": "Unsuccessful"})
        fig, ax = plt.subplots(figsize=(9, 5))
        plot.plot(kind="bar", stacked=True, ax=ax)
        ax.set_title("Known Landing Outcomes by Launch Site")
        ax.set_xlabel("Launch site"); ax.set_ylabel("Number of labelled attempts")
        fig.tight_layout(); fig.savefig(FIG / "landing_outcomes_by_site.png", dpi=160); plt.close(fig)
    # Payload by outcome
    if len(known) and known["payload_mass_kg"].notna().any():
        fig, ax = plt.subplots(figsize=(8, 4.8))
        known.boxplot(column="payload_mass_kg", by="landing_success", ax=ax)
        ax.set_title("Payload Mass by Landing Outcome"); ax.set_xlabel("Landing success (0 = no, 1 = yes)")
        ax.set_ylabel("Payload mass (kg)"); fig.suptitle("")
        fig.tight_layout(); fig.savefig(FIG / "payload_by_landing.png", dpi=160); plt.close(fig)
    # Correlation heatmap
    numeric = df.select_dtypes(include=[np.number]).dropna(axis=1, how="all")
    if len(numeric.columns) >= 2:
        fig, ax = plt.subplots(figsize=(8, 6))
        sns.heatmap(numeric.corr(numeric_only=True), annot=True, fmt=".2f", cmap="coolwarm", center=0, ax=ax)
        ax.set_title("Correlation Heatmap of Numeric Variables")
        fig.tight_layout(); fig.savefig(FIG / "correlation_heatmap.png", dpi=160); plt.close(fig)
    # Folium map
    geo = df.dropna(subset=["latitude", "longitude", "launch_site"]).copy()
    if len(geo):
        center = [geo["latitude"].mean(), geo["longitude"].mean()]
        m = folium.Map(location=center, zoom_start=4, control_scale=True)
        for _, r in geo.drop_duplicates(subset=["launch_site"]).iterrows():
            site_rows = df[df["launch_site"] == r["launch_site"]]
            known_site = site_rows.dropna(subset=["landing_success"])
            rate = (known_site["landing_success"].mean() * 100) if len(known_site) else None
            popup = f"{r['launch_site']}<br>Launches: {len(site_rows)}<br>Known landing success rate: {rate:.1f}%" if rate is not None else f"{r['launch_site']}<br>Launches: {len(site_rows)}<br>Landing rate unavailable"
            folium.Marker([r["latitude"], r["longitude"]], popup=popup, tooltip=r["launch_site"]).add_to(m)
        m.save(str(FIG / "folium_launch_sites.html"))
    return

def train_models(df):
    print("[6/7] Training and evaluating classification models...")
    data = df.dropna(subset=["landing_success"]).copy()
    data["landing_success"] = data["landing_success"].astype(int)
    if len(data) < 12 or data["landing_success"].nunique() < 2:
        (OUT / "model_metrics.csv").write_text("model,accuracy,precision,recall,f1\n", encoding="utf-8")
        return {"status": "Insufficient labelled records/classes for reliable supervised modelling", "labelled_rows": int(len(data)), "class_counts": data["landing_success"].value_counts().to_dict()}
    features = ["year", "payload_mass_kg", "orbit", "launch_site", "core_reused"]
    X = data[features].copy()
    y = data["landing_success"].astype(int)
    categorical = ["orbit", "launch_site"]
    numeric = ["year", "payload_mass_kg", "core_reused"]
    preprocessor = ColumnTransformer([
        ("num", Pipeline([("imputer", SimpleImputer(strategy="median")), ("scale", StandardScaler())]), numeric),
        ("cat", Pipeline([("imputer", SimpleImputer(strategy="most_frequent")), ("onehot", OneHotEncoder(handle_unknown="ignore"))]), categorical)
    ])
    counts = y.value_counts()
    stratify = y if counts.min() >= 2 else None
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42, stratify=stratify)
    models = {
        "Dummy baseline": DummyClassifier(strategy="most_frequent"),
        "Logistic Regression": LogisticRegression(max_iter=2000, class_weight="balanced"),
        "SVM": SVC(class_weight="balanced"),
        "Decision Tree": DecisionTreeClassifier(max_depth=4, random_state=42, class_weight="balanced"),
        "K-Nearest Neighbors": KNeighborsClassifier(n_neighbors=min(5, max(1, len(X_train)//3))),
        "Random Forest": RandomForestClassifier(n_estimators=300, random_state=42, class_weight="balanced", min_samples_leaf=2)
    }
    rows, reports = [], {}
    best_pipe, best_f1 = None, -1
    for name, model in models.items():
        pipe = Pipeline([("prep", preprocessor), ("model", model)])
        pipe.fit(X_train, y_train)
        pred = pipe.predict(X_test)
        metrics = {
            "model": name,
            "accuracy": accuracy_score(y_test, pred),
            "precision": precision_score(y_test, pred, zero_division=0),
            "recall": recall_score(y_test, pred, zero_division=0),
            "f1": f1_score(y_test, pred, zero_division=0),
            "test_rows": len(y_test)
        }
        rows.append(metrics)
        reports[name] = classification_report(y_test, pred, zero_division=0)
        if metrics["f1"] > best_f1 and name != "Dummy baseline":
            best_f1, best_pipe = metrics["f1"], pipe
            cm = confusion_matrix(y_test, pred, labels=[0,1])
            fig, ax = plt.subplots(figsize=(4.8, 4))
            sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", xticklabels=["Predicted 0", "Predicted 1"], yticklabels=["Actual 0", "Actual 1"], ax=ax)
            ax.set_title(f"Confusion Matrix: {name}"); fig.tight_layout()
            fig.savefig(FIG / "best_model_confusion_matrix.png", dpi=160); plt.close(fig)
    metrics_df = pd.DataFrame(rows).sort_values(["f1", "accuracy"], ascending=False)
    metrics_df.to_csv(OUT / "model_metrics.csv", index=False)
    (OUT / "classification_reports.json").write_text(json.dumps(reports, indent=2), encoding="utf-8")
    if best_pipe is not None:
        import joblib
        joblib.dump(best_pipe, OUT / "best_landing_model.joblib")
    return {"status": "completed", "labelled_rows": int(len(data)), "class_counts": {str(k): int(v) for k,v in y.value_counts().items()}, "train_rows": int(len(y_train)), "test_rows": int(len(y_test)), "metrics": metrics_df.to_dict(orient="records"), "best_by_f1": str(metrics_df.iloc[0]["model"])}

def generate_report(df, sql_results, scrape_meta, model_results):
    print("[7/7] Generating PDF report from actual run outputs...")
    pdf = OUT / "Data_Science_Capstone_Project_Report.pdf"
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="Small", parent=styles["BodyText"], fontSize=8, leading=10))
    story = []
    story += [Paragraph("Data Science Capstone Project Report", styles["Title"]),
              Paragraph("Predicting SpaceX Falcon 9 First-Stage Landing Success", styles["Heading2"]),
              Paragraph(f"Generated from data retrieved on {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}.", styles["Italic"]),
              Spacer(1, 14)]
    n = len(df); known = df.dropna(subset=["landing_success"]); success_rate = known["landing_success"].mean() if len(known) else None
    story += [Paragraph("1. Executive Summary", styles["Heading1"]),
              Paragraph(f"This project investigates whether a Falcon 9 first stage lands successfully using public launch records. The pipeline collected {n} Falcon 9 records from the SpaceX API, prepared a cleaned dataset, ran SQL-based exploratory queries, produced visual and geospatial analysis, and evaluated classification models where explicit landing labels were available. {('Among '+str(len(known))+' records with known labels, the observed landing success proportion was '+format(success_rate*100, '.1f')+'%.') if success_rate is not None else 'The API did not provide enough explicit landing labels to calculate an observed landing success rate.'}", styles["BodyText"]),
              Paragraph("This report reflects the outputs of this execution. Model metrics can vary with API changes, label availability, and the train/test split.", styles["BodyText"]),
              Paragraph("2. Introduction and Business Problem", styles["Heading1"]),
              Paragraph("The first stage is a major component of launch cost. Reuse can reduce launch costs, so estimating the likelihood of a successful landing is useful for understanding operational performance. The task is framed as binary classification: 1 means an explicitly recorded successful landing and 0 means an explicitly recorded unsuccessful landing. Unknown outcomes are not automatically recoded as failures.", styles["BodyText"]),
              Paragraph("3. Data Collection Methodology", styles["Heading1"]),
              Paragraph("Launches, rocket metadata, launchpad metadata, payload records, and core records were collected from SpaceX API v4. Records were joined using API identifiers. Falcon 9 launches were retained based on the rocket metadata. Raw API output and collection metadata are saved under outputs/.", styles["BodyText"]),
              Paragraph(f"Supplemental web-scraping status: {scrape_meta.get('status','not available')}. Source: {WIKI}", styles["Small"]),
              Paragraph("4. Data Wrangling", styles["Heading1"]),
              Paragraph("Dates were parsed into UTC timestamps and year values; duplicate flight numbers were removed; Boolean outcome/reuse values were mapped to numeric indicators. Missing values were preserved for descriptive analysis. For supervised classification, rows with unknown landing outcomes were excluded and feature imputation was performed inside a scikit-learn pipeline to reduce leakage.", styles["BodyText"]),
              Paragraph(f"Cleaned dataset rows: {len(df)}. Records with explicit landing labels: {len(known)}. Unknown landing labels: {len(df)-len(known)}.", styles["BodyText"]),
              Paragraph("5. EDA and Visualization Methodology", styles["Heading1"]),
              Paragraph("The analysis includes annual launch counts, known landing outcomes by launch site, payload mass by landing outcome, and a numeric correlation heatmap where data are available. These charts are saved in the figures/ directory.", styles["BodyText"])]
    for img in ["launches_by_year.png","landing_outcomes_by_site.png","payload_by_landing.png","correlation_heatmap.png"]:
        p = FIG / img
        if p.exists():
            story += [Spacer(1, 8), Image(str(p), width=6.2*inch, height=3.3*inch), Paragraph(img.replace("_"," ").replace(".png","").title(), styles["Caption"])]
    story += [Paragraph("6. EDA with SQL", styles["Heading1"]),
              Paragraph("The cleaned data were loaded into a local SQLite database. Queries summarize launches by site, launches by year, labelled landing outcomes by site, and average payload by orbit. SQL statements are stored in outputs/sql_queries.json and each result table is exported as a CSV.", styles["BodyText"])]
    for key, records in sql_results.items():
        story.append(Paragraph(key.replace("_"," ").title(), styles["Heading3"]))
        if records:
            cols = list(records[0].keys())
            data = [cols] + [[str(r.get(c, ""))[:40] for c in cols] for r in records[:10]]
            tbl = Table(data, repeatRows=1)
            tbl.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#17365D")),("TEXTCOLOR",(0,0),(-1,0),colors.white),("GRID",(0,0),(-1,-1),0.35,colors.grey),("FONTSIZE",(0,0),(-1,-1),7),("VALIGN",(0,0),(-1,-1),"TOP")]))
            story += [tbl, Spacer(1, 8)]
        else:
            story.append(Paragraph("No results were returned for this query.", styles["BodyText"]))
    story += [Paragraph("7. Folium Launch-Site Map", styles["Heading1"]),
              Paragraph("An interactive Folium map was generated with one marker per launch site. Marker popups show launch counts and the landing success rate among records with known outcomes. Open figures/folium_launch_sites.html in a browser to inspect the map.", styles["BodyText"]),
              Paragraph("8. Plotly Dash Dashboard", styles["Heading1"]),
              Paragraph("The included app.py provides interactive filtering by launch site and displays launch counts, payload mass distribution, and available landing outcomes. Run the app locally after running the pipeline. The dashboard is generated from outputs/spacex_falcon9_cleaned.csv.", styles["BodyText"]),
              Paragraph("9. Predictive Analysis (Classification)", styles["Heading1"]),
              Paragraph("The target is the explicit landing_success label. Candidate models are a majority-class baseline, Logistic Regression, Support Vector Machine, Decision Tree, K-Nearest Neighbors, and Random Forest. Categorical features are one-hot encoded; numeric features are median-imputed and standardized. A fixed random seed is used for a reproducible holdout split.", styles["BodyText"])]
    if model_results.get("status") == "completed":
        story.append(Paragraph(f"Labelled rows: {model_results['labelled_rows']}; training rows: {model_results['train_rows']}; test rows: {model_results['test_rows']}. Best non-baseline model by the script's F1 comparison: {model_results.get('best_by_f1','not available')}.", styles["BodyText"]))
        mdf = pd.read_csv(OUT / "model_metrics.csv")
        data = [["Model","Accuracy","Precision","Recall","F1"]]
        for _, r in mdf.iterrows():
            data.append([str(r["model"]), *(f"{r[c]:.3f}" for c in ["accuracy","precision","recall","f1"])])
        tbl = Table(data, repeatRows=1)
        tbl.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#17365D")),("TEXTCOLOR",(0,0),(-1,0),colors.white),("GRID",(0,0),(-1,-1),0.35,colors.grey),("FONTSIZE",(0,0),(-1,-1),8)]))
        story += [tbl, Spacer(1, 10)]
        cm_img = FIG / "best_model_confusion_matrix.png"
        if cm_img.exists():
            story.append(Image(str(cm_img), width=4.7*inch, height=3.8*inch))
    else:
        story.append(Paragraph(f"Model evaluation was not completed because: {model_results.get('status')}. This is reported transparently rather than filling in fabricated metrics.", styles["BodyText"]))
    story += [Paragraph("10. Results and Interpretation", styles["Heading1"]),
              Paragraph("Interpretation should focus on the generated figures, SQL tables, class distribution, and test metrics. Accuracy alone can be misleading if landing outcomes are imbalanced; precision, recall, F1-score, and the confusion matrix should also be considered. Results from a small historical dataset should not be treated as a guarantee of future landing outcomes.", styles["BodyText"]),
              Paragraph("11. Conclusion, Limitations, and Future Work", styles["Heading1"]),
              Paragraph("This workflow combines public API collection, supplemental scraping, data cleaning, SQL queries, exploratory visualization, geospatial mapping, dashboarding, and supervised classification. Key limitations include missing outcome labels, possible API schema changes, small sample size, and changes in launch technology over time. Future work could add more validated features, time-aware validation, calibration, and monitoring on newly released launch records.", styles["BodyText"]),
              Paragraph("12. Reproducibility and Repository", styles["Heading1"]),
              Paragraph("The scripts, dependencies, generated data, figures, and metrics should be uploaded to the learner's own GitHub repository. Replace the line below with the real repository URL after publishing the project; do not submit a made-up URL.", styles["BodyText"]),
              Paragraph("GitHub repository URL: [ADD YOUR OWN REPOSITORY URL AFTER UPLOADING]", styles["BodyText"]),
              Paragraph("Appendix: SQL query file, raw/cleaned CSV files, model metrics CSV, classification reports, SQLite database, and generated figures are saved in outputs/ and figures/.", styles["BodyText"])]
    doc = SimpleDocTemplate(str(pdf), pagesize=letter, rightMargin=0.65*inch, leftMargin=0.65*inch, topMargin=0.65*inch, bottomMargin=0.65*inch)
    doc.build(story)
    print(f"PDF generated at: {pdf}")

def main():
    df = collect_data()
    scrape_meta = scrape_wikipedia()
    (OUT / "scrape_metadata.json").write_text(json.dumps(scrape_meta, indent=2), encoding="utf-8")
    df = wrangle(df)
    sql_results = sql_eda(df)
    make_visuals(df)
    model_results = train_models(df)
    (OUT / "model_run_summary.json").write_text(json.dumps(model_results, indent=2), encoding="utf-8")
    generate_report(df, sql_results, scrape_meta, model_results)
    print("\nPipeline finished. Review outputs/ and figures/.")
    print("Important: inspect the report, confirm the results make sense, and add your own GitHub repository URL before submission.")

if __name__ == "__main__":
    main()
