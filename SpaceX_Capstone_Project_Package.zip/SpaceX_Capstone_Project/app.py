from pathlib import Path
import pandas as pd
import plotly.express as px
from dash import Dash, dcc, html, Input, Output

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "outputs" / "spacex_falcon9_cleaned.csv"
if not DATA.exists():
    raise SystemExit("Run `python run_project.py` first to generate outputs/spacex_falcon9_cleaned.csv")
df = pd.read_csv(DATA)
sites = sorted([s for s in df["launch_site"].dropna().unique()])
app = Dash(__name__)
app.title = "SpaceX Falcon 9 Landing Analysis"
app.layout = html.Div([
    html.H1("SpaceX Falcon 9 First-Stage Landing Analysis"),
    html.P("Interactive dashboard generated from the collected and cleaned SpaceX API dataset."),
    html.Label("Filter by launch site"),
    dcc.Dropdown(options=[{"label":"All sites","value":"ALL"}]+[{"label":s,"value":s} for s in sites],
                 value="ALL", id="site-filter", clearable=False),
    html.Div(id="summary", style={"padding":"12px"}),
    dcc.Graph(id="launch-chart"),
    dcc.Graph(id="payload-chart"),
    dcc.Graph(id="landing-chart")
], style={"maxWidth":"1100px","margin":"auto","fontFamily":"Arial"})

@app.callback(
    Output("summary","children"), Output("launch-chart","figure"),
    Output("payload-chart","figure"), Output("landing-chart","figure"),
    Input("site-filter","value")
)
def update(site):
    d = df if site == "ALL" else df[df["launch_site"] == site]
    labelled = d.dropna(subset=["landing_success"])
    rate = labelled["landing_success"].mean()*100 if len(labelled) else None
    summary = f"Launch records: {len(d)} | Labelled landing outcomes: {len(labelled)} | Observed success rate: {rate:.1f}%" if rate is not None else f"Launch records: {len(d)} | No explicit landing labels available for this filter."
    by_year = d.dropna(subset=["year"]).groupby("year").size().reset_index(name="launches")
    fig1 = px.bar(by_year, x="year", y="launches", title="Launches by Year")
    fig2 = px.histogram(d.dropna(subset=["payload_mass_kg"]), x="payload_mass_kg", color="orbit", title="Payload Mass Distribution by Orbit")
    land = labelled.groupby("landing_success").size().reset_index(name="records")
    if len(land):
        land["outcome"] = land["landing_success"].map({0:"Unsuccessful",1:"Successful"})
    fig3 = px.bar(land, x="outcome", y="records", title="Explicitly Recorded Landing Outcomes")
    return summary, fig1, fig2, fig3

if __name__ == "__main__":
    app.run(debug=False)
